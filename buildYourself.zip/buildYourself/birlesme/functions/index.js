const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.scheduledFunction = functions.pubsub
  .schedule("every day 00:00")
  .onRun(async (context) => {
    const now = new Date();
    const snapshot = await admin
      .firestore()
      .collection("reservations")
      .where("date", "<", now)
      .get();

    const batch = admin.firestore().batch();
    snapshot.docs.forEach((doc) => {
      batch.delete(doc.ref);
    });

    await batch.commit();
    console.log("Old reservations deleted");
    return null;
  });
