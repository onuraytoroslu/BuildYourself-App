class CustomUser {
  final String uid;
  CustomUser({required this.uid});
}