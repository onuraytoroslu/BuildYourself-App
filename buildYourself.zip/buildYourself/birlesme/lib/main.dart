import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:ui';
import 'package:table_calendar/table_calendar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'dart:math';
import 'package:fl_chart/fl_chart.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => SettingsController(),
      child: Consumer<SettingsController>(
        builder: (context, settingsController, child) {
          return MaterialApp(
            title: 'buildYourself',
            theme: ThemeData(
              brightness: settingsController.isDarkMode
                  ? Brightness.dark
                  : Brightness.light,
              primaryColor: Colors.deepOrange,
              appBarTheme: AppBarTheme(
                backgroundColor:
                    settingsController.isDarkMode ? Colors.black : Colors.white,
                iconTheme: IconThemeData(color: Colors.deepOrange),
              ),
            ),
            initialRoute: '/',
            routes: {
              '/': (context) => SignUpScreen(),
              '/login': (context) => LoginScreen(),
              '/profile': (context) => ProfilePage(),
              '/faq': (context) => FAQScreen(),
              '/notifications': (context) => NotificationsScreen(),
              '/settings': (context) => AppSettingsScreen(),
              '/home': (context) => HomePage(),
              '/lockerPage': (context) => LockerPage(),
              '/lockerPageUnlocked': (context) => LockerPageUnlocked(),
              '/contactUs': (context) => ContactUsPage(),
            },
            onGenerateRoute: (settings) {
              if (settings.name == '/musclesPage') {
                final args = settings.arguments as Map<String, dynamic>;
                return MaterialPageRoute(
                  builder: (context) {
                    return MusclesPage(
                      selectedDate: args['selectedDate'],
                      selectedTime: args['selectedTime'],
                      workoutType: args['workoutType'],
                    );
                  },
                );
              }
              return null; // Default route
            },
          );
        },
      ),
    );
  }
}

class SettingsController extends ChangeNotifier {
  bool _isDarkMode = false;

  bool get isDarkMode => _isDarkMode;

  void toggleDarkMode() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }
}

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool _isLoading = false;

  void _register() async {
    if (passwordController.text != confirmPasswordController.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Passwords do not match")),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text,
      );
      User? user = userCredential.user;

      if (user != null) {
        final String signUpDate = DateTime.now().toIso8601String();
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'name': nameController.text,
          'gender': genderController.text,
          'signUpDate': signUpDate,
          'profileImageUrl': '', // Varsayılan boş bir profil resmi URL'si
          'height': '',
          'weight': '',
          'age': '',
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Registered Successfully!!")),
        );
        Navigator.pushReplacementNamed(context, '/home');
      }
    } on FirebaseAuthException catch (e) {
      String message = "An error occurred";
      if (e.code == 'weak-password') {
        message = "The password provided is too weak.";
      } else if (e.code == 'email-already-in-use') {
        message = "The account already exists for that email.";
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          body: Stack(
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Center(
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'buildYourself',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrange,
                          ),
                        ),
                        Text(
                          '💪',
                          style: TextStyle(
                            fontSize: 50,
                          ),
                        ),
                        SizedBox(height: 20),
                        _buildTextField(nameController, 'Name Surname'),
                        SizedBox(height: 10),
                        _buildTextField(emailController, 'Email'),
                        SizedBox(height: 10),
                        _buildTextField(passwordController, 'Password',
                            obscureText: true),
                        SizedBox(height: 10),
                        _buildTextField(
                            confirmPasswordController, 'Confirm Password',
                            obscureText: true),
                        SizedBox(height: 10),
                        _buildTextField(genderController, 'Gender'),
                        SizedBox(height: 20),
                        _isLoading
                            ? CircularProgressIndicator()
                            : ElevatedButton(
                                onPressed: _register,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: settingsController.isDarkMode
                                      ? Colors.black
                                      : Colors.white,
                                  foregroundColor: Colors.deepOrange,
                                  side: BorderSide(color: Colors.deepOrange),
                                ),
                                child: Text(
                                  'Sign Up!',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                        GestureDetector(
                          onTap: () {
                            Navigator.pushNamed(context, '/login');
                          },
                          child: Text(
                            'Already have an account!',
                            style: TextStyle(
                              color: Colors.deepOrange,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTextField(TextEditingController controller, String hintText,
      {bool obscureText = false}) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return TextField(
          controller: controller,
          obscureText: obscureText,
          style: TextStyle(color: Colors.deepOrange),
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.deepOrange),
            filled: true,
            fillColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            contentPadding:
                EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
          ),
        );
      },
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool _obscureText = true;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  void _login() async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text,
      );
      User? user = userCredential.user;

      if (user != null) {
        Navigator.pushReplacementNamed(context, '/home');
      }
    } on FirebaseAuthException catch (e) {
      String message = "An error occurred";
      if (e.code == 'user-not-found') {
        message = "No user found for that email.";
      } else if (e.code == 'wrong-password') {
        message = "Wrong password provided.";
      } else if (e.message != null) {
        message = e.message!;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("An unexpected error occurred.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          body: Stack(
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Center(
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'buildYourself',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrange,
                          ),
                        ),
                        Text(
                          '💪',
                          style: TextStyle(
                            fontSize: 50,
                          ),
                        ),
                        SizedBox(height: 20),
                        _buildTextField(emailController, 'Email'),
                        SizedBox(height: 10),
                        _buildPasswordTextField(passwordController, 'Password'),
                        SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: _login,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: settingsController.isDarkMode
                                ? Colors.black
                                : Colors.white,
                            foregroundColor: Colors.deepOrange,
                            side: BorderSide(color: Colors.deepOrange),
                          ),
                          child: Text(
                            'Log In',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.pushNamed(context, '/');
                          },
                          child: Text(
                            'Sign up for buildYourself',
                            style: TextStyle(
                              color: Colors.deepOrange,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  color: Colors.deepOrange,
                  padding: EdgeInsets.symmetric(vertical: 5.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Forgot your login details?',
                        style: TextStyle(
                          color: settingsController.isDarkMode
                              ? Colors.black
                              : Colors.white,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          _showRecoveryMailDialog(context);
                        },
                        style: TextButton.styleFrom(
                          foregroundColor: settingsController.isDarkMode
                              ? Colors.white
                              : Colors.black,
                        ),
                        child: Text('Get help logging in'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTextField(TextEditingController controller, String hintText,
      {bool obscureText = false}) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return TextField(
          controller: controller,
          obscureText: obscureText,
          style: TextStyle(color: Colors.deepOrange),
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.deepOrange),
            filled: true,
            fillColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            contentPadding:
                EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
          ),
        );
      },
    );
  }

  Widget _buildPasswordTextField(
      TextEditingController controller, String hintText) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return TextField(
          controller: controller,
          obscureText: _obscureText,
          style: TextStyle(color: Colors.deepOrange),
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.deepOrange),
            filled: true,
            fillColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(color: Colors.deepOrange),
            ),
            contentPadding:
                EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
            suffixIcon: IconButton(
              icon: Icon(
                _obscureText ? Icons.visibility : Icons.visibility_off,
                color: Colors.deepOrange,
              ),
              onPressed: () {
                setState(() {
                  _obscureText = !_obscureText;
                });
              },
            ),
          ),
        );
      },
    );
  }

  void _showRecoveryMailDialog(BuildContext context) {
    final TextEditingController recoveryEmailController =
        TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Send recovery mail',
                      style: TextStyle(
                        color: Colors.deepOrange,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ],
                ),
                TextField(
                  controller: recoveryEmailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    fillColor: Colors.deepOrange,
                    border: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.deepOrange,
                        width: 2.0,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.blue,
                        width: 2.0,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.deepOrange,
                        width: 2.0,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () async {
                    await _auth.sendPasswordResetEmail(
                        email: recoveryEmailController.text);
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Recovery email sent")),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    foregroundColor: Colors.white,
                  ),
                  child: Text(
                    'Send',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  User? _user;
  String? _name;
  String? _email;
  String? _gender;
  String? _signUpDate;
  String? _height;
  String? _weight;
  String? _age;
  String? _profileImageUrl;
  Map<DateTime, List<dynamic>> _reservationsData = {};
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();

  @override
  void initState() {
    super.initState();
    _user = _auth.currentUser;
    if (_user != null) {
      _fetchUserData();
      _fetchReservationsData();
    }
  }

  Future<void> _fetchUserData() async {
    DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(_user!.uid)
        .get();
    if (userDoc.exists) {
      setState(() {
        _name = userDoc['name'];
        _email = _user!.email;
        _gender = userDoc['gender'];
        _signUpDate = DateFormat('dd/MM/yyyy')
            .format(DateTime.parse(userDoc['signUpDate']));
        _height = userDoc.data().toString().contains('height')
            ? '${userDoc.get('height')} cm'
            : '';
        _weight = userDoc.data().toString().contains('weight')
            ? '${userDoc.get('weight')} kg'
            : '';
        _age =
            userDoc.data().toString().contains('age') ? userDoc.get('age') : '';
        _profileImageUrl = userDoc.data().toString().contains('profileImageUrl')
            ? userDoc.get('profileImageUrl')
            : null;
      });
    }
  }

  Future<void> _fetchReservationsData() async {
    QuerySnapshot reservationsSnapshot = await FirebaseFirestore.instance
        .collection('reservations')
        .where('userId', isEqualTo: _user!.uid)
        .get();

    Map<DateTime, List<dynamic>> reservationsData = {};

    for (var doc in reservationsSnapshot.docs) {
      DateTime date = (doc['date'] as Timestamp).toDate();
      reservationsData[DateTime(date.year, date.month, date.day)] = [
        'reserved'
      ];
    }

    setState(() {
      _reservationsData = reservationsData;
    });
  }

  void _logout() async {
    await _auth.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  Future<void> _navigateToEditProfile() async {
    DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(_user!.uid)
        .get();
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => EditProfilePage(userDoc: userDoc)),
    );
    if (result == true) {
      _fetchUserData(); // Fetch updated data after returning from edit page
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            title: Text('Profile', style: TextStyle(color: Colors.deepOrange)),
            iconTheme: IconThemeData(color: Colors.deepOrange),
            // Update back button color
            actions: [
              IconButton(
                icon: Icon(Icons.logout, color: Colors.deepOrange),
                onPressed: _logout,
              ),
              IconButton(
                icon: Icon(Icons.edit, color: Colors.deepOrange),
                onPressed: _navigateToEditProfile,
              ),
            ],
          ),
          body: _user == null
              ? Center(child: CircularProgressIndicator())
              : Padding(
                  padding: EdgeInsets.all(8.0),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Column(
                            children: [
                              CircleAvatar(
                                radius: 40,
                                backgroundColor: Colors.deepOrange,
                                backgroundImage: _profileImageUrl != null &&
                                        _profileImageUrl!.isNotEmpty
                                    ? NetworkImage(_profileImageUrl!)
                                    : null,
                                child: _profileImageUrl == null ||
                                        _profileImageUrl!.isEmpty
                                    ? Text(
                                        _name != null && _name!.isNotEmpty
                                            ? _name![0]
                                            : '',
                                        style: TextStyle(
                                          fontSize: 40,
                                          color: Colors.white,
                                        ),
                                      )
                                    : null,
                              ),
                              SizedBox(height: 10),
                              Text(
                                _name ?? '',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.deepOrange,
                                ),
                              ),
                              SizedBox(height: 5),
                              Text(
                                _email ?? '',
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.deepOrange,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 20),
                        _buildProfileInfoRow('Gender', _gender),
                        Divider(),
                        _buildProfileInfoRow('Member Since', _signUpDate),
                        Divider(),
                        _buildProfileInfoRow('Height', _height),
                        Divider(),
                        _buildProfileInfoRow('Weight', _weight),
                        Divider(),
                        _buildProfileInfoRow('Age', _age),
                        SizedBox(height: 20),
                        Text(
                          'Attendance',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.deepOrange,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TableCalendar(
                          firstDay: DateTime.utc(2020, 1, 1),
                          lastDay: DateTime.utc(2030, 12, 31),
                          focusedDay: _focusedDay,
                          selectedDayPredicate: (day) {
                            return isSameDay(_selectedDay, day);
                          },
                          onDaySelected: (selectedDay, focusedDay) {
                            if (selectedDay.isBefore(DateTime.now())) {
                              setState(() {
                                _selectedDay = selectedDay;
                                _focusedDay = focusedDay;
                              });
                            }
                          },
                          calendarBuilders: CalendarBuilders(
                            defaultBuilder: (context, day, focusedDay) {
                              if (day.isBefore(DateTime.now())) {
                                final isReserved = _reservationsData[DateTime(
                                            day.year, day.month, day.day)]
                                        ?.contains('reserved') ??
                                    false;

                                return Container(
                                  margin: const EdgeInsets.all(2.0),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color:
                                        isReserved ? Colors.green : Colors.red,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Text(
                                    '${day.day}',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                    ),
                                  ),
                                );
                              }
                              return null;
                            },
                          ),
                          calendarStyle: CalendarStyle(
                            todayDecoration: BoxDecoration(
                              color: Colors.orange,
                              shape: BoxShape.circle,
                            ),
                            selectedDecoration: BoxDecoration(
                              color: Colors.blue,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        );
      },
    );
  }

  Widget _buildProfileInfoRow(String title, String? value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 18,
              color: Colors.deepOrange,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            value ?? '',
            style: TextStyle(
              fontSize: 18,
              color: Colors.deepOrange,
            ),
          ),
        ],
      ),
    );
  }
}

class EditProfilePage extends StatefulWidget {
  final DocumentSnapshot userDoc;

  const EditProfilePage({required this.userDoc});

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  File? _imageFile;

  @override
  void initState() {
    super.initState();
    _heightController.text = widget.userDoc.data().toString().contains('height')
        ? widget.userDoc.get('height') ?? ''
        : '';
    _weightController.text = widget.userDoc.data().toString().contains('weight')
        ? widget.userDoc.get('weight') ?? ''
        : '';
    _ageController.text = widget.userDoc.data().toString().contains('age')
        ? widget.userDoc.get('age') ?? ''
        : '';
  }

  Future<void> _pickImage() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  Future<void> _updateProfile() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        String? profileImageUrl;

        if (_imageFile != null) {
          // Upload new profile image
          final ref = FirebaseStorage.instance
              .ref()
              .child('profile_images')
              .child('${user.uid}.jpg');
          await ref.putFile(_imageFile!);
          profileImageUrl = await ref.getDownloadURL();
        }

        await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .update({
          'height': _heightController.text,
          'weight': _weightController.text,
          'age': _ageController.text,
          if (profileImageUrl != null) 'profileImageUrl': profileImageUrl,
        });

        Navigator.pop(
            context, true); // Return true to indicate the profile was updated
      }
    } catch (e) {
      print('Failed to update profile: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            title: Text('Edit Profile',
                style: TextStyle(color: Colors.deepOrange)),
            iconTheme: IconThemeData(color: Colors.deepOrange),
          ),
          body: Padding(
            padding: EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _pickImage,
                    child: CircleAvatar(
                      radius: 40,
                      backgroundColor: Colors.deepOrange,
                      backgroundImage:
                          _imageFile != null ? FileImage(_imageFile!) : null,
                      child: _imageFile == null
                          ? Icon(Icons.camera_alt, color: Colors.white)
                          : null,
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: _heightController,
                    decoration: InputDecoration(
                      labelText: 'Height (cm)',
                      labelStyle: TextStyle(color: Colors.deepOrange),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepOrange),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepOrange),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                    style: TextStyle(color: Colors.deepOrange),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: _weightController,
                    decoration: InputDecoration(
                      labelText: 'Weight (kg)',
                      labelStyle: TextStyle(color: Colors.deepOrange),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepOrange),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepOrange),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                    style: TextStyle(color: Colors.deepOrange),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: _ageController,
                    decoration: InputDecoration(
                      labelText: 'Age',
                      labelStyle: TextStyle(color: Colors.deepOrange),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepOrange),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.deepOrange),
                      ),
                    ),
                    keyboardType: TextInputType.number,
                    style: TextStyle(color: Colors.deepOrange),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _updateProfile,
                    child: Text('Update',
                        style: TextStyle(
                            color: settingsController.isDarkMode
                                ? Colors.black
                                : Colors.white)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepOrange,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class FAQScreen extends StatelessWidget {
  const FAQScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: Builder(
              builder: (BuildContext context) {
                return IconButton(
                  icon: Icon(Icons.menu),
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  color: Colors.deepOrange,
                );
              },
            ),
            title: Text('FAQ\'s', style: TextStyle(color: Colors.deepOrange)),
            centerTitle: true,
            actions: [
              IconButton(
                icon: Icon(Icons.person),
                onPressed: () {
                  Navigator.pushNamed(context, '/profile');
                },
                color: Colors.deepOrange,
              ),
            ],
          ),
          drawer: buildDrawer(context),
          body: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20),
                Expanded(
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 20,
                    mainAxisSpacing: 20,
                    children: [
                      _buildFAQCard(context, 'Who are we?',
                          'Welcome to buildYourself, your ultimate fitness companion. Our app is designed to help you easily book gym reservations, manage your fitness schedule, and achieve your health goals. With buildYourself, you can track your progress, join a community of like-minded individuals, and get personalized fitness advice. Whether you are a beginner or a seasoned athlete, buildYourself is here to support you on your fitness journey.'),
                      _buildFAQCard(
                          context,
                          'What happens if I miss my reservation?',
                          'If you miss your reservation, you may be charged a fee or lose your spot. Please check our cancellation policy for more details.'),
                      _buildFAQCard(
                          context,
                          'Are there any restrictions on the number of reservations I can make?',
                          'Yes, there are limits to the number of reservations you can make per month. Please refer to our membership guidelines for more information.'),
                      _buildFAQCard(
                          context,
                          'Can I bring a guest with me to my gym session?',
                          'Yes, you can bring a guest with you. Guests must sign in at the front desk and adhere to all gym policies.'),
                      _buildFAQCard(
                          context,
                          'Is there a waitlist if all slots are booked?',
                          'Yes, if all slots are booked, you can join the waitlist. You will be notified if a slot becomes available.'),
                      _buildFAQCard(
                          context,
                          'Can I cancel or reschedule my reservation?',
                          'Yes, you can cancel or reschedule your reservation up to 24 hours before your scheduled time. Please use our app or website to make changes.'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Drawer buildDrawer(BuildContext context) {
    return Drawer(
      child: Consumer<SettingsController>(
        builder: (context, settingsController, child) {
          return Container(
            color: Colors.deepOrange,
            child: Column(
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          icon: Icon(Icons.close, color: Colors.deepOrange),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '💪',
                          style: TextStyle(fontSize: 50),
                        ),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text('Home',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
                ListTile(
                  title: Text('Notifications',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/notifications');
                  },
                ),
                ListTile(
                  title: Text('FAQ\'s',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/faq');
                  },
                ),
                ListTile(
                  title: Text('App Settings',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                Divider(color: Colors.white),
                ListTile(
                  title: Text('Contact Us',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/contactUs');
                  },
                ),
                ListTile(
                  title: Text('Log out',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    _showLogoutDialog(context);
                  },
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Text('buildYourself®',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                'Are you sure you want to log out?',
                style: TextStyle(color: Colors.deepOrange),
                textAlign: TextAlign.center,
              ),
              actions: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: Icon(Icons.check, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pushReplacementNamed(context, '/login');
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildFAQCard(BuildContext context, String question, String answer) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return GestureDetector(
          onTap: () {
            showModalBottomSheet(
              context: context,
              builder: (BuildContext context) {
                return Container(
                  padding: EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16.0),
                      topRight: Radius.circular(16.0),
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Icon(Icons.keyboard_arrow_down,
                            size: 30, color: Colors.deepOrange),
                      ),
                      SizedBox(height: 10),
                      Text(
                        question,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrange),
                      ),
                      SizedBox(height: 10),
                      Text(
                        answer,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrange),
                      ),
                    ],
                  ),
                );
              },
            );
          },
          child: Card(
            color: settingsController.isDarkMode ? Colors.black : Colors.white,
            shape: RoundedRectangleBorder(
              side: BorderSide(color: Colors.deepOrange, width: 2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  question,
                  style: TextStyle(
                    color: Colors.deepOrange,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: Builder(
              builder: (BuildContext context) {
                return IconButton(
                  icon: Icon(Icons.menu),
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  color: Colors.deepOrange,
                );
              },
            ),
            title: Text('Notifications',
                style: TextStyle(color: Colors.deepOrange)),
            centerTitle: true,
            actions: [
              IconButton(
                icon: Icon(Icons.person),
                onPressed: () {
                  Navigator.pushNamed(context, '/profile');
                },
                color: Colors.deepOrange,
              ),
            ],
          ),
          drawer: buildDrawer(context),
          body: Padding(
            padding: EdgeInsets.all(16.0),
            child: ListView(
              children: [
                _buildNotificationCard(context, 'Maintenance',
                    'We\'re sorry to announce that there will be a maintenance in the gym between 16.00 - 19.00 on 14.04.2024. So the gym will be closed.'),
                _buildNotificationCard(context, 'Yoga Class',
                    'Join our new yoga class starting next week! Classes are available every Tuesday and Thursday at 10 AM.'),
                _buildNotificationCard(context, 'Promotional Offer',
                    'Don\'t miss our special promotional offer! Get 20% off on all memberships purchased before the end of this month.'),
                _buildNotificationCard(context, 'Membership Renewal',
                    'Reminder: Your membership is up for renewal on 30.04.2024. Renew now to continue enjoying all the benefits.'),
                _buildNotificationCard(context, 'Feedback Request',
                    'We value your feedback! Please take a moment to fill out our feedback form and let us know how we\'re doing.'),
                _buildNotificationCard(context, 'New Classes Available',
                    'We have added new classes to our schedule! Check out the latest additions and find the perfect class for you.'),
                _buildNotificationCard(context, 'Holiday Hours',
                    'Please note our holiday hours for the upcoming season. The gym will be closed on 25.12.2024 and 01.01.2025.'),
                _buildNotificationCard(context, 'Trainer Availability',
                    'Our trainers have updated their availability. Book your sessions now to secure your preferred time slots.'),
                _buildNotificationCard(context, 'Special Event',
                    'Join us for a special event this weekend! Enjoy free classes, meet our trainers, and participate in fun activities.'),
                _buildNotificationCard(context, 'System Update',
                    'We will be performing a system update on 20.04.2024. During this time, the app may be temporarily unavailable.'),
                _buildNotificationCard(context, 'Monthly Newsletter',
                    'Check out our monthly newsletter for the latest news, tips, and updates from buildYourself.'),
                _buildNotificationCard(context, 'Personal Training Offer',
                    'Special offer: Get a free personal training session with the purchase of any new membership!'),
              ],
            ),
          ),
        );
      },
    );
  }

  Drawer buildDrawer(BuildContext context) {
    return Drawer(
      child: Consumer<SettingsController>(
        builder: (context, settingsController, child) {
          return Container(
            color: Colors.deepOrange,
            child: Column(
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          icon: Icon(Icons.close, color: Colors.deepOrange),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '💪',
                          style: TextStyle(fontSize: 50),
                        ),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text('Home',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
                ListTile(
                  title: Text('Notifications',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/notifications');
                  },
                ),
                ListTile(
                  title: Text('FAQ\'s',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/faq');
                  },
                ),
                ListTile(
                  title: Text('App Settings',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                Divider(color: Colors.white),
                ListTile(
                  title: Text('Contact Us',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/contactUs');
                  },
                ),
                ListTile(
                  title: Text('Log out',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    _showLogoutDialog(context);
                  },
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Text('buildYourself®',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                'Are you sure you want to log out?',
                style: TextStyle(color: Colors.deepOrange),
                textAlign: TextAlign.center,
              ),
              actions: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: Icon(Icons.check, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pushReplacementNamed(context, '/login');
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildNotificationCard(
      BuildContext context, String title, String details) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return GestureDetector(
          onTap: () {
            showModalBottomSheet(
              context: context,
              builder: (BuildContext context) {
                return Container(
                  padding: EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16.0),
                      topRight: Radius.circular(16.0),
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Icon(Icons.keyboard_arrow_down,
                            size: 30, color: Colors.deepOrange),
                      ),
                      SizedBox(height: 10),
                      Text(
                        title,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrange),
                      ),
                      SizedBox(height: 10),
                      Text(
                        details,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrange),
                      ),
                    ],
                  ),
                );
              },
            );
          },
          child: Card(
            color: settingsController.isDarkMode ? Colors.black : Colors.white,
            shape: RoundedRectangleBorder(
              side: BorderSide(color: Colors.deepOrange, width: 2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: ListTile(
              leading: Icon(Icons.mail_outline, color: Colors.deepOrange),
              title: Text(
                title,
                style: TextStyle(
                  color: Colors.deepOrange,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class AppSettingsScreen extends StatelessWidget {
  const AppSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: Builder(
              builder: (BuildContext context) {
                return IconButton(
                  icon: Icon(Icons.menu),
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  color: Colors.deepOrange,
                );
              },
            ),
            title: Text('App Settings',
                style: TextStyle(color: Colors.deepOrange)),
            centerTitle: true,
            actions: [
              IconButton(
                icon: Icon(Icons.person),
                onPressed: () {
                  Navigator.pushNamed(context, '/profile');
                },
                color: Colors.deepOrange,
              ),
            ],
          ),
          drawer: buildDrawer(context),
          body: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20),
                Expanded(
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    children: [
                      _buildSettingsCard('E-mail Preferences',
                          Icon(Icons.email, color: Colors.deepOrange)),
                      _buildSettingsCard('Notifications',
                          Icon(Icons.notifications, color: Colors.deepOrange)),
                      _buildSettingsCard('Data Usage',
                          Icon(Icons.data_usage, color: Colors.deepOrange)),
                      _buildSettingsCard(
                          'Dark Mode',
                          Switch(
                            value: settingsController.isDarkMode,
                            onChanged: (value) {
                              settingsController.toggleDarkMode();
                            },
                            activeColor: Colors.deepOrange,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Drawer buildDrawer(BuildContext context) {
    return Drawer(
      child: Consumer<SettingsController>(
        builder: (context, settingsController, child) {
          return Container(
            color: Colors.deepOrange,
            child: Column(
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          icon: Icon(Icons.close, color: Colors.deepOrange),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '💪',
                          style: TextStyle(fontSize: 50),
                        ),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text('Home',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
                ListTile(
                  title: Text('Notifications',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/notifications');
                  },
                ),
                ListTile(
                  title: Text('FAQ\'s',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/faq');
                  },
                ),
                ListTile(
                  title: Text('App Settings',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                Divider(color: Colors.white),
                ListTile(
                  title: Text('Contact Us',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/contactUs');
                  },
                ),
                ListTile(
                  title: Text('Log out',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    _showLogoutDialog(context);
                  },
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Text('buildYourself®',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                'Are you sure you want to log out?',
                style: TextStyle(color: Colors.deepOrange),
                textAlign: TextAlign.center,
              ),
              actions: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: Icon(Icons.check, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pushReplacementNamed(context, '/login');
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildSettingsCard(String title, Widget trailingWidget) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Card(
          color: settingsController.isDarkMode ? Colors.black : Colors.white,
          shape: RoundedRectangleBorder(
            side: BorderSide(color: Colors.deepOrange, width: 2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: ListTile(
            title: Text(
              title,
              style: TextStyle(
                color: Colors.deepOrange,
                fontWeight: FontWeight.bold,
              ),
            ),
            trailing: trailingWidget,
          ),
        );
      },
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isBottomSheetExpanded = false;
  List<DocumentSnapshot> _reservations = [];

  void _toggleBottomSheet() {
    setState(() {
      _isBottomSheetExpanded = !_isBottomSheetExpanded;
    });
  }

  int generateRandomLockerNumber() {
    final random = Random();
    return random.nextInt(100) + 1;
  }

  void _showSuccessDialog(BuildContext context, int lockerNumber) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
          child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            backgroundColor: Colors.greenAccent,
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      icon: Icon(Icons.close, color: Colors.black),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pushNamed(context, '/lockerPage',
                            arguments: lockerNumber);
                      },
                    ),
                  ),
                  Icon(Icons.check_circle, size: 100, color: Colors.green),
                  SizedBox(height: 20),
                  Text('Success!',
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)),
                  SizedBox(height: 10),
                  Text('Your locker no is:',
                      style: TextStyle(fontSize: 18, color: Colors.black)),
                  SizedBox(height: 10),
                  Text("$lockerNumber",
                      style: TextStyle(
                          fontSize: 48,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _navigateToAppointmentPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AppointmentPage()),
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchReservations();
  }

  Future<void> _fetchReservations() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('reservations')
          .where('userId', isEqualTo: user.uid)
          .orderBy('date', descending: false)
          .get();

      setState(() {
        _reservations = snapshot.docs;
        _removePastReservations(); // Remove past reservations
      });
    }
  }

  void _removePastReservations() {
    DateTime now = DateTime.now();
    _reservations.removeWhere((reservation) {
      DateTime date = reservation['date'].toDate();
      // Compare only date parts (ignoring time)
      return date.isBefore(DateTime(now.year, now.month, now.day));
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: Builder(
              builder: (BuildContext context) {
                return IconButton(
                  icon: Icon(Icons.menu),
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  color: Colors.deepOrange,
                );
              },
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.person),
                onPressed: () {
                  Navigator.pushNamed(context, '/profile');
                },
                color: Colors.deepOrange,
              ),
            ],
          ),
          drawer: buildDrawer(context),
          body: Stack(
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Entrance',
                      style: TextStyle(color: Colors.deepOrange, fontSize: 20),
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () {
                        int lockerNumber = generateRandomLockerNumber();
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return BackdropFilter(
                              filter:
                                  ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                              child: Dialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                backgroundColor: Colors.deepOrange,
                                child: Padding(
                                  padding: EdgeInsets.all(16.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: IconButton(
                                          icon: Icon(Icons.close,
                                              color: Colors.white),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.of(context).pop();
                                          _showSuccessDialog(
                                              context, lockerNumber);
                                        },
                                        child: Column(
                                          children: [
                                            QrImageView(
                                              data: user!.uid,
                                              backgroundColor: Colors.white,
                                            ),
                                            SizedBox(height: 20),
                                            Text('Entrance QR',
                                                style: TextStyle(
                                                    fontSize: 24,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.white)),
                                            SizedBox(height: 10),
                                            Text(
                                              'Please show the QR code to the scanner.',
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  color: Colors.white),
                                              textAlign: TextAlign.center,
                                            ),
                                            SizedBox(height: 10),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                        foregroundColor: Colors.deepOrange,
                        side: BorderSide(color: Colors.deepOrange, width: 1),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'Generate QR',
                            style: TextStyle(
                              color: Colors.deepOrange,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(width: 5),
                          Icon(Icons.qr_code, color: Colors.deepOrange),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Reservations',
                      style: TextStyle(color: Colors.deepOrange, fontSize: 20),
                    ),
                    SizedBox(height: 10),
                    Center(
                      child: IconButton(
                        icon: Icon(Icons.add_circle,
                            size: 30, color: Colors.deepOrange),
                        onPressed: _navigateToAppointmentPage,
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _reservations.length,
                        itemBuilder: (context, index) {
                          final reservation = _reservations[index];
                          final date = reservation['date'].toDate();
                          final time = reservation['time'];
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: _buildReservationCard(reservation, index),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: GestureDetector(
                  onVerticalDragUpdate: (details) {
                    if (details.primaryDelta! < 0) {
                      _toggleBottomSheet();
                    }
                  },
                  child: AnimatedContainer(
                    duration: Duration(milliseconds: 300),
                    height: _isBottomSheetExpanded
                        ? MediaQuery.of(context).size.height * 0.6
                        : 150,
                    decoration: BoxDecoration(
                      color: Colors.deepOrange,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(
                            sigmaX: _isBottomSheetExpanded ? 10.0 : 0.0,
                            sigmaY: _isBottomSheetExpanded ? 10.0 : 0.0),
                        child: Column(
                          children: [
                            IconButton(
                              icon: Icon(
                                _isBottomSheetExpanded
                                    ? Icons.keyboard_arrow_down
                                    : Icons.keyboard_arrow_up,
                                color: settingsController.isDarkMode
                                    ? Colors.black
                                    : Colors.white,
                              ),
                              onPressed: _toggleBottomSheet,
                            ),
                            Expanded(
                              child: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 16.0),
                                      child: Text(
                                        'Our Products',
                                        style: TextStyle(
                                            color: settingsController.isDarkMode
                                                ? Colors.black
                                                : Colors.white,
                                            fontSize: 20),
                                      ),
                                    ),
                                    SizedBox(height: 10),
                                    SizedBox(
                                      height: 150,
                                      child: ListView(
                                        scrollDirection: Axis.horizontal,
                                        children: [
                                          _buildProductCard('BCAA', '19.99\$',
                                              'assets/bcaa.jfif'),
                                          _buildProductCard('Protein',
                                              '29.99\$', 'assets/protein.jfif'),
                                          _buildProductCard(
                                              'Rice Protein',
                                              '24.99\$',
                                              'assets/rice_protein.jfif'),
                                          _buildProductCard(
                                              'Whey Isolate',
                                              '34.99\$',
                                              'assets/protein_tozu.jfif'),
                                          _buildProductCard('Creatine',
                                              '14.99\$', 'assets/creatin.jfif'),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 20),
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 16.0),
                                      child: Text(
                                        'Events',
                                        style: TextStyle(
                                            color: settingsController.isDarkMode
                                                ? Colors.black
                                                : Colors.white,
                                            fontSize: 20),
                                      ),
                                    ),
                                    SizedBox(height: 10),
                                    _buildEventCard(
                                        'A yoga event will be held at 25 April between 18.00 and 20.00.',
                                        '25 April',
                                        'assets/yoga.jfif'),
                                    _buildEventCard(
                                        'A strength training workshop will be held at 1 May between 14.00 and 16.00.',
                                        '1 May',
                                        'assets/strength_training.jfif'),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildReservationCard(DocumentSnapshot reservation, int index) {
    DateTime date = reservation['date'].toDate();
    String time = reservation['time'];
    List muscles = List.from(reservation['muscles']);

    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return GestureDetector(
          onTap: () {
            _showReservationDetails(context, reservation);
          },
          child: Container(
            padding: EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              border: Border.all(color: Colors.deepOrange),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${date.day}/${date.month}/${date.year}',
                        style: TextStyle(
                          color: Colors.deepOrange,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        time,
                        style: TextStyle(
                          color: Colors.deepOrange,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Muscles: ${muscles.join(', ')}',
                        style: TextStyle(
                          color: Colors.deepOrange,
                          fontSize: 14,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2, // Adjust this to fit your design
                      ),
                    ],
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: Colors.deepOrange),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showReservationDetails(
      BuildContext context, DocumentSnapshot reservation) {
    DateTime date = reservation['date'].toDate();
    String time = reservation['time'];
    List muscles = List.from(reservation['muscles']);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              title: Text(
                'Reservation Details',
                style: TextStyle(color: Colors.deepOrange),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Date: ${date.day}/${date.month}/${date.year}',
                    style: TextStyle(color: Colors.deepOrange),
                  ),
                  Text(
                    'Time: $time',
                    style: TextStyle(color: Colors.deepOrange),
                  ),
                  Text(
                    'Muscles: ${muscles.join(', ')}',
                    style: TextStyle(color: Colors.deepOrange),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      _showDeleteConfirmation(context, reservation);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                    ),
                    child: Text('Cancel Reservation'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showDeleteConfirmation(
      BuildContext context, DocumentSnapshot reservation) {
    DateTime date = reservation['date'].toDate();
    String timeString =
        reservation['time']; // Assuming time is stored as a string like "14:30"
    // Split the time string into time and period (AM/PM)
    List<String> muscles = List<String>.from(reservation['muscles']);
    List<String> parts = timeString.split(' ');
    String timePart = parts[0]; // "12:00"
    String periodPart = parts[1]; // "PM"

    // Split the time part into hours and minutes
    List<String> timeParts = timePart.split(':');
    int hour = int.parse(timeParts[0]);
    int minute = int.parse(timeParts[1]);

    // Adjust hour based on AM/PM
    if (periodPart == 'PM' && hour != 12) {
      hour += 12;
    } else if (periodPart == 'AM' && hour == 12) {
      hour = 0;
    }

    // Create TimeOfDay object
    TimeOfDay time = TimeOfDay(hour: hour, minute: minute);
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              title: Text(
                'Are you sure?',
                style: TextStyle(color: Colors.deepOrange),
              ),
              content: Text(
                'Do you really want to cancel this reservation? This action cannot be undone.',
                style: TextStyle(color: Colors.deepOrange),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('No', style: TextStyle(color: Colors.deepOrange)),
                ),
                TextButton(
                  onPressed: () {
                    _cancelReservation(reservation.id);
                    _decreaseCrowdednessAndSessionInfo(date, time, muscles);
                    Navigator.of(context).pop();
                  },
                  child:
                      Text('Yes', style: TextStyle(color: Colors.deepOrange)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _cancelReservation(String reservationId) async {
    await FirebaseFirestore.instance
        .collection('reservations')
        .doc(reservationId)
        .delete();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Reservation cancelled')),
    );
    _fetchReservations();
  }

  Widget _buildProductCard(String name, String price, String imagePath) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Container(
          width: 100,
          padding: EdgeInsets.all(8.0),
          margin: EdgeInsets.symmetric(horizontal: 8.0),
          decoration: BoxDecoration(
            color: settingsController.isDarkMode ? Colors.black : Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 6,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Colors.grey, width: 1),
            ),
            child: Column(
              children: [
                Expanded(child: Image.asset(imagePath, fit: BoxFit.cover)),
                Text(name,
                    style: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.white
                            : Colors.black)),
                Text(price,
                    style: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.white
                            : Colors.black)),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEventCard(String description, String date, String imagePath) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          decoration: BoxDecoration(
            color: settingsController.isDarkMode ? Colors.black : Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 6,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Colors.grey, width: 1),
            ),
            child: Column(
              children: [
                Image.asset(imagePath, fit: BoxFit.cover),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(description,
                      style: TextStyle(
                          color: settingsController.isDarkMode
                              ? Colors.white
                              : Colors.black)),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(date,
                      style: TextStyle(
                          color: settingsController.isDarkMode
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Drawer buildDrawer(BuildContext context) {
    return Drawer(
      child: Consumer<SettingsController>(
        builder: (context, settingsController, child) {
          return Container(
            color: Colors.deepOrange,
            child: Column(
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          icon: Icon(Icons.close, color: Colors.deepOrange),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '💪',
                          style: TextStyle(fontSize: 50),
                        ),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text('Home',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
                ListTile(
                  title: Text('Notifications',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/notifications');
                  },
                ),
                ListTile(
                  title: Text('FAQ\'s',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/faq');
                  },
                ),
                ListTile(
                  title: Text('App Settings',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                Divider(color: Colors.white),
                ListTile(
                  title: Text('Contact Us',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/contactUs');
                  },
                ),
                ListTile(
                  title: Text('Log out',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    _showLogoutDialog(context);
                  },
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Text('buildYourself®',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                'Are you sure you want to log out?',
                style: TextStyle(color: Colors.deepOrange),
                textAlign: TextAlign.center,
              ),
              actions: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: Icon(Icons.check, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pushReplacementNamed(context, '/login');
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class LockerPage extends StatefulWidget {
  const LockerPage({super.key});

  @override
  _LockerPageState createState() => _LockerPageState();
}

class _LockerPageState extends State<LockerPage> {
  bool _isBottomSheetExpanded = false;
  List<DocumentSnapshot> _reservations = [];

  void _toggleBottomSheet() {
    setState(() {
      _isBottomSheetExpanded = !_isBottomSheetExpanded;
    });
  }

  void _showUnlockConfirmationDialog(int lockerNumber) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            "Are you sure you want to unlock it?",
            style: TextStyle(color: Colors.deepOrange),
          ),
          actions: [
            TextButton(
              child: Text("No", style: TextStyle(color: Colors.deepOrange)),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text("Yes", style: TextStyle(color: Colors.deepOrange)),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushNamed(context, '/lockerPageUnlocked',
                    arguments: lockerNumber);
              },
            ),
          ],
        );
      },
    );
  }

  void _navigateToAppointmentPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AppointmentPage()),
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchReservations();
  }

  Future<void> _fetchReservations() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('reservations')
          .where('userId', isEqualTo: user.uid)
          .orderBy('date', descending: false)
          .get();

      setState(() {
        _reservations = snapshot.docs;
        _removePastReservations(); // Remove past reservations
      });
    }
  }

  void _removePastReservations() {
    DateTime now = DateTime.now();
    _reservations.removeWhere((reservation) {
      DateTime date = reservation['date'].toDate();
      // Compare only date parts (ignoring time)
      return date.isBefore(DateTime(now.year, now.month, now.day));
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final int? lockerNumber =
        ModalRoute.of(context)!.settings.arguments as int?;
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: Builder(
              builder: (BuildContext context) {
                return IconButton(
                  icon: Icon(Icons.menu),
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  color: Colors.deepOrange,
                );
              },
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.person),
                onPressed: () {
                  Navigator.pushNamed(context, '/profile');
                },
                color: Colors.deepOrange,
              ),
            ],
          ),
          drawer: buildDrawer(context),
          body: Stack(
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Session',
                      style: TextStyle(color: Colors.deepOrange, fontSize: 20),
                    ),
                    SizedBox(height: 10),
                    Center(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(
                              backgroundColor: settingsController.isDarkMode
                                  ? Colors.white
                                  : Colors.black,
                              foregroundColor: settingsController.isDarkMode
                                  ? Colors.black
                                  : Colors.white,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.lock),
                                SizedBox(width: 5),
                                Text('Locker $lockerNumber'),
                              ],
                            ),
                          ),
                          SizedBox(width: 6),
                          IconButton(
                            icon: Icon(Icons.door_front_door),
                            color: Colors.deepOrange,
                            onPressed: () => _showUnlockConfirmationDialog(
                                lockerNumber ?? 54),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Reservations',
                      style: TextStyle(color: Colors.deepOrange, fontSize: 20),
                    ),
                    SizedBox(height: 10),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _reservations.length,
                        itemBuilder: (context, index) {
                          final reservation = _reservations[index];
                          final date = reservation['date'].toDate();
                          final time = reservation['time'];
                          final muscles =
                              List<String>.from(reservation['muscles']);
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: _buildReservationCard(date, time),
                          );
                        },
                      ),
                    ),
                    Center(
                      child: IconButton(
                        icon: Icon(Icons.add_circle,
                            size: 30, color: Colors.deepOrange),
                        onPressed: _navigateToAppointmentPage,
                      ),
                    ),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: GestureDetector(
                  onVerticalDragUpdate: (details) {
                    if (details.primaryDelta! < 0) {
                      _toggleBottomSheet();
                    }
                  },
                  child: AnimatedContainer(
                    duration: Duration(milliseconds: 300),
                    height: _isBottomSheetExpanded
                        ? MediaQuery.of(context).size.height * 0.6
                        : 150,
                    decoration: BoxDecoration(
                      color: Colors.deepOrange,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(
                            sigmaX: _isBottomSheetExpanded ? 10.0 : 0.0,
                            sigmaY: _isBottomSheetExpanded ? 10.0 : 0.0),
                        child: Column(
                          children: [
                            IconButton(
                              icon: Icon(
                                _isBottomSheetExpanded
                                    ? Icons.keyboard_arrow_down
                                    : Icons.keyboard_arrow_up,
                                color: settingsController.isDarkMode
                                    ? Colors.black
                                    : Colors.white,
                              ),
                              onPressed: _toggleBottomSheet,
                            ),
                            Expanded(
                              child: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 16.0),
                                      child: Text(
                                        'Our Products',
                                        style: TextStyle(
                                            color: settingsController.isDarkMode
                                                ? Colors.black
                                                : Colors.white,
                                            fontSize: 20),
                                      ),
                                    ),
                                    SizedBox(height: 10),
                                    SizedBox(
                                      height: 150,
                                      child: ListView(
                                        scrollDirection: Axis.horizontal,
                                        children: [
                                          _buildProductCard('BCAA', '19.99\$',
                                              'assets/bcaa.jfif'),
                                          _buildProductCard('Protein',
                                              '29.99\$', 'assets/protein.jfif'),
                                          _buildProductCard(
                                              'Rice Protein',
                                              '24.99\$',
                                              'assets/rice_protein.jfif'),
                                          _buildProductCard(
                                              'Whey Isolate',
                                              '34.99\$',
                                              'assets/protein_tozu.jfif'),
                                          _buildProductCard('Creatine',
                                              '14.99\$', 'assets/creatin.jfif'),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 20),
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 16.0),
                                      child: Text(
                                        'Events',
                                        style: TextStyle(
                                            color: settingsController.isDarkMode
                                                ? Colors.black
                                                : Colors.white,
                                            fontSize: 20),
                                      ),
                                    ),
                                    SizedBox(height: 10),
                                    Column(
                                      children: [
                                        _buildEventCard(
                                            'A yoga event will be held at 25 April between 18.00 and 20.00.',
                                            '25 April',
                                            'assets/yoga.jfif'),
                                        _buildEventCard(
                                            'A strength training workshop will be held at 1 May between 14.00 and 16.00.',
                                            '1 May',
                                            'assets/strength_training.jfif'),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildReservationCard(DateTime date, String time) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Card(
          color: settingsController.isDarkMode ? Colors.black : Colors.white,
          shape: RoundedRectangleBorder(
            side: BorderSide(color: Colors.deepOrange, width: 2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: ListTile(
            leading: Text('💪', style: TextStyle(fontSize: 30)),
            title: Text(
              '${date.day}/${date.month}/${date.year}',
              style: TextStyle(
                color: Colors.deepOrange,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              time,
              style: TextStyle(
                color: Colors.deepOrange,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildProductCard(String name, String price, String imagePath) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Container(
          width: 100,
          padding: EdgeInsets.all(8.0),
          margin: EdgeInsets.symmetric(horizontal: 8.0),
          decoration: BoxDecoration(
            color: settingsController.isDarkMode ? Colors.black : Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 6,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Colors.grey, width: 1),
            ),
            child: Column(
              children: [
                Expanded(child: Image.asset(imagePath, fit: BoxFit.cover)),
                Text(name,
                    style: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.white
                            : Colors.black)),
                Text(price,
                    style: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.white
                            : Colors.black)),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEventCard(String description, String date, String imagePath) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          decoration: BoxDecoration(
            color: settingsController.isDarkMode ? Colors.black : Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 6,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Colors.grey, width: 1),
            ),
            child: Column(
              children: [
                Image.asset(imagePath, fit: BoxFit.cover),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(description,
                      style: TextStyle(
                          color: settingsController.isDarkMode
                              ? Colors.white
                              : Colors.black)),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(date,
                      style: TextStyle(
                          color: settingsController.isDarkMode
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Drawer buildDrawer(BuildContext context) {
    return Drawer(
      child: Consumer<SettingsController>(
        builder: (context, settingsController, child) {
          return Container(
            color: Colors.deepOrange,
            child: Column(
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          icon: Icon(Icons.close, color: Colors.deepOrange),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '💪',
                          style: TextStyle(fontSize: 50),
                        ),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text('Home',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
                ListTile(
                  title: Text('Notifications',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/notifications');
                  },
                ),
                ListTile(
                  title: Text('FAQ\'s',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/faq');
                  },
                ),
                ListTile(
                  title: Text('App Settings',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                Divider(color: Colors.white),
                ListTile(
                  title: Text('Contact Us',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/contactUs');
                  },
                ),
                ListTile(
                  title: Text('Log out',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    _showLogoutDialog(context);
                  },
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Text('buildYourself®',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                'Are you sure you want to log out?',
                style: TextStyle(color: Colors.deepOrange),
                textAlign: TextAlign.center,
              ),
              actions: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: Icon(Icons.check, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pushReplacementNamed(context, '/login');
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class LockerPageUnlocked extends StatefulWidget {
  const LockerPageUnlocked({super.key});

  @override
  _LockerPageUnlockedState createState() => _LockerPageUnlockedState();
}

class _LockerPageUnlockedState extends State<LockerPageUnlocked> {
  bool _isBottomSheetExpanded = false;
  final user = FirebaseAuth.instance.currentUser;
  int lockerNumber = 54; // Default value
  List<DocumentSnapshot> _reservations = [];

  void _toggleBottomSheet() {
    setState(() {
      _isBottomSheetExpanded = !_isBottomSheetExpanded;
    });
  }

  void _showExitQRDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          backgroundColor: Colors.deepOrange,
          content: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    icon: Icon(Icons.close,
                        color: Colors.white), // İkon rengini siyah yapıyoruz
                    onPressed: () {
                      Navigator.of(context).pop(); // Pop-up'ı kapat
                      Navigator.pushReplacementNamed(
                          context, '/home'); // HomePage'e yönlendir
                    },
                  ),
                ),
                QrImageView(
                  data: user!.uid,
                  backgroundColor: Colors.white,
                ),
                SizedBox(height: 10),
                Text('Exit QR',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
                SizedBox(height: 10),
                Text(
                  'Make sure you don’t have any belongings in your locker',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _navigateToAppointmentPage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AppointmentPage()),
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchReservations();
  }

  Future<void> _fetchReservations() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('reservations')
          .where('userId', isEqualTo: user.uid)
          .orderBy('date', descending: false)
          .get();

      setState(() {
        _reservations = snapshot.docs;
        _removePastReservations(); // Remove past reservations
      });
    }
  }

  void _removePastReservations() {
    DateTime now = DateTime.now();
    _reservations.removeWhere((reservation) {
      DateTime date = reservation['date'].toDate();
      // Compare only date parts (ignoring time)
      return date.isBefore(DateTime(now.year, now.month, now.day));
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final int? passedLockerNumber =
        ModalRoute.of(context)!.settings.arguments as int?;
    lockerNumber =
        passedLockerNumber ?? lockerNumber; // Update locker number if passed

    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: Builder(
              builder: (BuildContext context) {
                return IconButton(
                  icon: Icon(Icons.menu),
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  color: Colors.deepOrange,
                );
              },
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.person),
                onPressed: () {
                  Navigator.pushNamed(context, '/profile');
                },
                color: Colors.deepOrange,
              ),
            ],
          ),
          drawer: buildDrawer(context),
          body: Stack(
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Session',
                      style: TextStyle(color: Colors.deepOrange, fontSize: 20),
                    ),
                    SizedBox(height: 10),
                    Center(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.lock_open),
                                SizedBox(width: 5),
                                Text('Locker $lockerNumber'),
                              ],
                            ),
                          ),
                          SizedBox(
                              width: 6), // Butonlar arasına boşluk ekliyoruz
                          IconButton(
                            icon: Icon(Icons.door_front_door),
                            color: Colors.deepOrange,
                            onPressed: _showExitQRDialog,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Reservations',
                      style: TextStyle(color: Colors.deepOrange, fontSize: 20),
                    ),
                    SizedBox(height: 10),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _reservations.length,
                        itemBuilder: (context, index) {
                          final reservation = _reservations[index];
                          final date = reservation['date'].toDate();
                          final time = reservation['time'];
                          return _buildReservationCard(date, time);
                        },
                      ),
                    ),
                    Center(
                      child: IconButton(
                        icon: Icon(Icons.add_circle,
                            size: 30, color: Colors.deepOrange),
                        onPressed: _navigateToAppointmentPage,
                      ),
                    ),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: GestureDetector(
                  onVerticalDragUpdate: (details) {
                    if (details.primaryDelta! < 0) {
                      _toggleBottomSheet();
                    }
                  },
                  child: AnimatedContainer(
                    duration: Duration(milliseconds: 300),
                    height: _isBottomSheetExpanded
                        ? MediaQuery.of(context).size.height * 0.6
                        : 150,
                    decoration: BoxDecoration(
                      color: Colors.deepOrange,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(
                            sigmaX: _isBottomSheetExpanded ? 10.0 : 0.0,
                            sigmaY: _isBottomSheetExpanded ? 10.0 : 0.0),
                        child: Column(
                          children: [
                            IconButton(
                              icon: Icon(
                                _isBottomSheetExpanded
                                    ? Icons.keyboard_arrow_down
                                    : Icons.keyboard_arrow_up,
                                color: settingsController.isDarkMode
                                    ? Colors.black
                                    : Colors.white,
                              ),
                              onPressed: _toggleBottomSheet,
                            ),
                            Expanded(
                              child: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 16.0),
                                      child: Text(
                                        'Our Products',
                                        style: TextStyle(
                                            color: settingsController.isDarkMode
                                                ? Colors.black
                                                : Colors.white,
                                            fontSize: 20),
                                      ),
                                    ),
                                    SizedBox(height: 10),
                                    SizedBox(
                                      height: 150,
                                      child: ListView(
                                        scrollDirection: Axis.horizontal,
                                        children: [
                                          _buildProductCard('BCAA', '19.99\$',
                                              'assets/bcaa.jfif'),
                                          _buildProductCard('Protein',
                                              '29.99\$', 'assets/protein.jfif'),
                                          _buildProductCard(
                                              'Rice Protein',
                                              '24.99\$',
                                              'assets/rice_protein.jfif'),
                                          _buildProductCard(
                                              'Whey Isolate',
                                              '34.99\$',
                                              'assets/protein_tozu.jfif'),
                                          _buildProductCard('Creatine',
                                              '14.99\$', 'assets/creatin.jfif'),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 20),
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 16.0),
                                      child: Text(
                                        'Events',
                                        style: TextStyle(
                                            color: settingsController.isDarkMode
                                                ? Colors.black
                                                : Colors.white,
                                            fontSize: 20),
                                      ),
                                    ),
                                    SizedBox(height: 10),
                                    Column(
                                      children: [
                                        _buildEventCard(
                                            'A yoga event will be held at 25 April between 18.00 and 20.00.',
                                            '25 April',
                                            'assets/yoga.jfif'),
                                        _buildEventCard(
                                            'A strength training workshop will be held at 1 May between 14.00 and 16.00.',
                                            '1 May',
                                            'assets/strength_training.jfif'),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildReservationCard(DateTime date, String time) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Card(
          color: settingsController.isDarkMode ? Colors.black : Colors.white,
          shape: RoundedRectangleBorder(
            side: BorderSide(color: Colors.deepOrange, width: 2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: ListTile(
            leading: Text('💪', style: TextStyle(fontSize: 30)),
            title: Text(
              '${date.day}/${date.month}/${date.year}',
              style: TextStyle(
                color: Colors.deepOrange,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              time,
              style: TextStyle(
                color: Colors.deepOrange,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildProductCard(String name, String price, String imagePath) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Container(
          width: 100,
          padding: EdgeInsets.all(8.0),
          margin: EdgeInsets.symmetric(horizontal: 8.0),
          decoration: BoxDecoration(
            color: settingsController.isDarkMode ? Colors.black : Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 6,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Colors.grey, width: 1),
            ),
            child: Column(
              children: [
                Expanded(child: Image.asset(imagePath, fit: BoxFit.cover)),
                Text(name,
                    style: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.white
                            : Colors.black)),
                Text(price,
                    style: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.white
                            : Colors.black)),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEventCard(String description, String date, String imagePath) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          decoration: BoxDecoration(
            color: settingsController.isDarkMode ? Colors.black : Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 6,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Colors.grey, width: 1),
            ),
            child: Column(
              children: [
                Image.asset(imagePath, fit: BoxFit.cover),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(description,
                      style: TextStyle(
                          color: settingsController.isDarkMode
                              ? Colors.white
                              : Colors.black)),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(date,
                      style: TextStyle(
                          color: settingsController.isDarkMode
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Drawer buildDrawer(BuildContext context) {
    return Drawer(
      child: Consumer<SettingsController>(
        builder: (context, settingsController, child) {
          return Container(
            color: Colors.deepOrange,
            child: Column(
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          icon: Icon(Icons.close, color: Colors.deepOrange),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '💪',
                          style: TextStyle(fontSize: 50),
                        ),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text('Home',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
                ListTile(
                  title: Text('Notifications',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/notifications');
                  },
                ),
                ListTile(
                  title: Text('FAQ\'s',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/faq');
                  },
                ),
                ListTile(
                  title: Text('App Settings',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                Divider(color: Colors.white),
                ListTile(
                  title: Text('Contact Us',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/contactUs');
                  },
                ),
                ListTile(
                  title: Text('Log out',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    _showLogoutDialog(context);
                  },
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Text('buildYourself®',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                'Are you sure you want to log out?',
                style: TextStyle(color: Colors.deepOrange),
                textAlign: TextAlign.center,
              ),
              actions: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: Icon(Icons.check, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pushReplacementNamed(context, '/login');
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }
}

Future<void> _updateCrowdednessAndSessionInfo(DateTime selectedDate,
    TimeOfDay selectedTime, int increment, List<String> muscles) async {
  String formattedDate = DateFormat('yyyy-MM-dd').format(selectedDate);
  DateTime startTime = DateTime(
    selectedDate.year,
    selectedDate.month,
    selectedDate.day,
    selectedTime.hour,
    (selectedTime.minute ~/ 10) * 10,
  );
  DateTime endTime = startTime.add(Duration(hours: 2));

  for (DateTime time = startTime;
      time.isBefore(endTime);
      time = time.add(Duration(minutes: 10))) {
    String timeKey = DateFormat.Hm().format(time);
    DocumentReference docRef = FirebaseFirestore.instance
        .collection('crowdedness')
        .doc(formattedDate)
        .collection('time_slices')
        .doc(timeKey);

    await docRef.get().then((doc) async {
      if (doc.exists) {
        var data = doc.data() as Map<String, dynamic>;
        int currentCount = data['count'] ?? 0;
        Map<String, int> currentMuscles = {
          for (var muscle in muscles) muscle: data[muscle] ?? 0
        };

        // Update count and muscles
        int newCount = currentCount + increment;
        if (newCount < 0) newCount = 0;

        Map<String, int> newMuscles = {};
        muscles.forEach((muscle) {
          int newMuscleCount = (currentMuscles[muscle] ?? 0) + increment;
          if (newMuscleCount < 0) newMuscleCount = 0;
          newMuscles[muscle] = newMuscleCount;
        });

        // Perform the update
        await docRef.update({
          'count': newCount,
          ...newMuscles,
        });
      } else if (increment > 0) {
        // Initialize count and muscles
        Map<String, int> initialData = {'count': increment};
        muscles.forEach((muscle) {
          initialData[muscle] = increment;
        });
        await docRef.set(initialData);
      }
    });
  }
}

Future<void> _decreaseCrowdednessAndSessionInfo(
    DateTime selectedDate, TimeOfDay selectedTime, List<String> muscles) async {
  try {
    await _updateCrowdednessAndSessionInfo(
        selectedDate, selectedTime, -1, muscles);
  } catch (e) {
    print('Error decreasing crowdedness and session info data: $e');
    // Handle the error appropriately here
  }
}

class AppointmentPage extends StatefulWidget {
  @override
  _AppointmentPageState createState() => _AppointmentPageState();
}

class _AppointmentPageState extends State<AppointmentPage> {
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  String _workoutType = 'CARDIO'; // Example value
  Map<String, int> _crowdednessData = {};
  Map<String, Map<String, int>> _sessionInfoData =
      {}; // New map for session info

  TimeOfDay _startTime = TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _endTime = TimeOfDay(hour: 23, minute: 0);

  @override
  void initState() {
    super.initState();
    _fetchCrowdednessData();
    _fetchSessionInfoData(); // Fetch session info data
  }

  Future<void> _fetchCrowdednessData() async {
    Map<String, int> data =
        await _fetchCrowdednessDataFromFirestore(_selectedDate);
    setState(() {
      _crowdednessData = data;
    });
  }

  Future<void> _fetchSessionInfoData() async {
    Map<String, Map<String, int>> data =
        await _fetchSessionInfoDataFromFirestore(_selectedDate);
    setState(() {
      _sessionInfoData = data;
    });
  }

  Future<Map<String, int>> _fetchCrowdednessDataFromFirestore(
      DateTime date) async {
    String formattedDate = DateFormat('yyyy-MM-dd').format(date);
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('crowdedness')
        .doc(formattedDate)
        .collection('time_slices')
        .get();

    Map<String, int> crowdednessData = {};
    for (var doc in querySnapshot.docs) {
      crowdednessData[doc.id] = doc['count'];
    }

    return crowdednessData;
  }

  Future<Map<String, Map<String, int>>> _fetchSessionInfoDataFromFirestore(
      DateTime date) async {
    String formattedDate = DateFormat('yyyy-MM-dd').format(date);
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('crowdedness')
        .doc(formattedDate)
        .collection('time_slices')
        .get();

    Map<String, Map<String, int>> sessionInfoData = {};
    for (var doc in querySnapshot.docs) {
      sessionInfoData[doc.id] = Map<String, int>.from(doc.data() as Map);
    }

    return sessionInfoData;
  }

  int _getSelectedTimeIndex() {
    DateTime startTime = DateTime(0, 1, 1, _startTime.hour, _startTime.minute);
    DateTime selectedDateTime =
        DateTime(0, 1, 1, _selectedTime.hour, _selectedTime.minute);
    int index = selectedDateTime.difference(startTime).inMinutes ~/ 10;
    int totalSlices = _calculateTotalSlices();
    if (index < 0) return 0;
    if (index >= totalSlices) return totalSlices - 1;
    return index;
  }

  int _calculateTotalSlices() {
    DateTime startTime = DateTime(0, 1, 1, _startTime.hour, _startTime.minute);
    DateTime endTime = DateTime(0, 1, 1, _endTime.hour, _endTime.minute);
    return endTime.difference(startTime).inMinutes ~/ 10;
  }

  List<String> _generateTimeLabels(int totalLabels) {
    DateTime startTime = DateTime(0, 1, 1, _startTime.hour, _startTime.minute);
    DateTime endTime = DateTime(0, 1, 1, _endTime.hour, _endTime.minute);
    int totalDuration = endTime.difference(startTime).inMinutes;

    List<String> labels = [];
    for (int i = 0; i <= totalLabels; i++) {
      DateTime labelTime =
          startTime.add(Duration(minutes: (totalDuration * i ~/ totalLabels)));
      labels.add(DateFormat.Hm().format(labelTime));
    }
    return labels;
  }

  Map<String, int> _aggregateSessionData() {
    DateTime startTime = DateTime(
      _selectedDate.year,
      _selectedDate.month,
      _selectedDate.day,
      _selectedTime.hour,
      (_selectedTime.minute ~/ 10) * 10,
    );
    DateTime endTime = startTime.add(Duration(hours: 2));

    Map<String, int> aggregatedData = {};

    for (DateTime time = startTime;
        time.isBefore(endTime);
        time = time.add(Duration(minutes: 10))) {
      String timeKey = DateFormat.Hm().format(time);
      if (_sessionInfoData.containsKey(timeKey)) {
        _sessionInfoData[timeKey]!.forEach((muscle, count) {
          if (muscle != 'count') {
            aggregatedData[muscle] = (aggregatedData[muscle] ?? 0) + count;
          }
        });
      }
    }

    aggregatedData.removeWhere((key, value) => value == 0);

    return aggregatedData;
  }

  List<PieChartSectionData> _buildPieChartSections() {
    Map<String, int> aggregatedData = _aggregateSessionData();

    if (aggregatedData.isEmpty) {
      // Return a single gray section when there is no data
      return [
        PieChartSectionData(
          color: Colors.grey,
          value: 100,
          title: '', // No title
          radius: 90,
        ),
      ];
    }

    int totalMuscleCount = aggregatedData.values.reduce((a, b) => a + b);

    return aggregatedData.entries.map((entry) {
      double percentage = (entry.value / totalMuscleCount) * 100;
      return PieChartSectionData(
        color: _getColorForMuscle(entry.key),
        value: percentage,
        title: '', // No title
        radius: 90,
      );
    }).toList();
  }

  Widget _buildLegend() {
    Map<String, int> aggregatedData = _aggregateSessionData();

    if (aggregatedData.isEmpty) {
      return Container(
        padding: EdgeInsets.all(16),
        child: Text('No Data', style: TextStyle(color: Colors.grey)),
      );
    }

    int totalMuscleCount = aggregatedData.values.reduce((a, b) => a + b);

    List<MapEntry<String, double>> sortedEntries = aggregatedData.entries
        .map((entry) =>
            MapEntry(entry.key, (entry.value / totalMuscleCount) * 100))
        .toList()
      ..sort(
          (a, b) => b.value.compareTo(a.value)); // Sorting in descending order

    return ListView(
      children: sortedEntries.map((entry) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 8,
                    height: 16,
                    color: _getColorForMuscle(entry.key),
                  ),
                  SizedBox(width: 8),
                  Text(entry.key),
                ],
              ),
              Text('${entry.value.toStringAsFixed(0)}%'),
            ],
          ),
        );
      }).toList(),
    );
  }

  Color _getColorForMuscle(String muscle) {
    switch (muscle) {
      case 'Legs':
        return Colors.blue[600]!; // A deep shade of blue
      case 'Core':
        return Colors.green[600]!; // A deep shade of green
      case 'Lats':
        return Colors.teal[600]!; // A deep shade of teal
      case 'Chest':
        return Colors.red[600]!; // A deep shade of red
      case 'Traps':
        return Colors.purple[600]!; // A deep shade of purple
      case 'Shoulders':
        return Colors.amber[600]!; // A deep shade of yellow
      case 'Triceps':
        return Colors.deepOrange[600]!; // A deep shade of orange
      case 'Glutes':
        return Colors.pink[600]!; // A deep shade of pink
      case 'Calves':
        return Colors.lime[600]!; // A deep shade of lime
      case 'Front Arm':
        return Colors.cyan[600]!; // A deep shade of cyan
      case 'Low Back':
        return Colors.brown[600]!; // A deep shade of brown
      case 'Biceps':
        return Colors.indigo[600]!; // A deep shade of indigo
      case 'Stretch':
        return Colors.lightGreen[600]!; // A deep shade of light green
      case 'Full Body':
        return Colors.blueGrey[600]!; // A deep shade of blue-grey
      case 'Cardio':
        return Colors.deepPurple[600]!; // A deep shade of deep purple
      default:
        return Colors.grey; // Neutral color for default
    }
  }

  @override
  Widget build(BuildContext context) {
    int selectedTimeIndex = _getSelectedTimeIndex();
    int totalSlices = _calculateTotalSlices();
    List<String> timeLabels =
        _generateTimeLabels(4); // Adjust the number of labels as needed

    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.deepOrange),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: Text(
              'Make Appointment',
              style: TextStyle(color: Colors.deepOrange),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MusclesPage(
                        selectedDate: _selectedDate,
                        selectedTime: _selectedTime,
                        workoutType: _workoutType,
                      ),
                    ),
                  );
                },
                child: Text('Next', style: TextStyle(color: Colors.deepOrange)),
              ),
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Date',
                  style: TextStyle(
                    color: Colors.deepOrange,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 10),
                TableCalendar(
                  firstDay: DateTime.utc(2020, 1, 1),
                  lastDay: DateTime.utc(2030, 12, 31),
                  focusedDay: _selectedDate,
                  calendarFormat: CalendarFormat.week,
                  onDaySelected: (selectedDay, focusedDay) {
                    setState(() {
                      _selectedDate = selectedDay;
                    });
                    _fetchCrowdednessData();
                    _fetchSessionInfoData();
                  },
                  selectedDayPredicate: (day) {
                    return isSameDay(_selectedDate, day);
                  },
                  daysOfWeekStyle: DaysOfWeekStyle(
                    weekdayStyle: TextStyle(color: Colors.deepOrangeAccent),
                    weekendStyle: TextStyle(color: Colors.deepOrange),
                  ),
                  calendarStyle: CalendarStyle(
                    defaultTextStyle: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.white
                            : Colors.black),
                    weekendTextStyle: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.white70
                            : Colors.deepOrange),
                    selectedTextStyle: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white),
                    todayTextStyle: TextStyle(
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white),
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  'Time',
                  style: TextStyle(
                    color: Colors.deepOrange,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () async {
                          TimeOfDay? picked = await showTimePicker(
                            context: context,
                            initialTime: _selectedTime,
                          );
                          if (picked != null && picked != _selectedTime) {
                            setState(() {
                              _selectedTime = picked;
                            });
                          }
                        },
                        child: Text(
                          'Select Time',
                          style: TextStyle(
                            color: Colors.deepOrange,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: settingsController.isDarkMode
                              ? Colors.black54
                              : Colors.white,
                          side: BorderSide(color: Colors.deepOrange, width: 1),
                        ),
                      ),
                    ),
                    SizedBox(width: 10),
                    Text(
                      '${_selectedTime.format(context)}',
                      style: TextStyle(
                        color: Colors.deepOrange,
                        fontSize: 24,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Text(
                  'Crowdedness',
                  style: TextStyle(
                    color: Colors.deepOrange,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 5),
                Stack(
                  children: [
                    Column(
                      children: [
                        // Time labels
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: List.generate(timeLabels.length, (index) {
                            return Expanded(
                              child: Text(
                                timeLabels[index],
                                style: TextStyle(color: Colors.deepOrange),
                                textAlign: index == 0
                                    ? TextAlign.left
                                    : index == timeLabels.length - 1
                                        ? TextAlign.right
                                        : TextAlign.center,
                              ),
                            );
                          }),
                        ),
                        // Crowdedness bar
                        Container(
                          height: 20,
                          child: LayoutBuilder(
                            builder: (context, constraints) {
                              double totalWidth = constraints.maxWidth;
                              double sliceWidth = totalWidth / totalSlices;

                              return Stack(
                                children: [
                                  Row(
                                    children:
                                        List.generate(totalSlices, (index) {
                                      String timeKey = DateFormat.Hm().format(
                                        DateTime(0, 1, 1, _startTime.hour,
                                                _startTime.minute)
                                            .add(Duration(minutes: index * 10)),
                                      );
                                      int value =
                                          _crowdednessData[timeKey] ?? 0;
                                      return Container(
                                        width: sliceWidth,
                                        height: 20,
                                        decoration: BoxDecoration(
                                          color: _getColorForCrowdedness(value),
                                          borderRadius: index == 0
                                              ? BorderRadius.horizontal(
                                                  left: Radius.circular(10))
                                              : index == totalSlices - 1
                                                  ? BorderRadius.horizontal(
                                                      right:
                                                          Radius.circular(10))
                                                  : BorderRadius.zero,
                                        ),
                                      );
                                    }),
                                  ),
                                  Positioned(
                                    left: selectedTimeIndex * sliceWidth,
                                    child: Container(
                                      width: 5,
                                      height: 40,
                                      color: Colors.deepOrange,
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Text(
                  'Session Info',
                  style: TextStyle(
                    color: Colors.deepOrange,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 10),
                SizedBox(height: 30),
                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Pie Chart
                        Expanded(
                          flex: 1,
                          child: SizedBox(
                            height: 200, // Specify the height
                            child: PieChart(
                              PieChartData(
                                sections: _buildPieChartSections(),
                                sectionsSpace: 0, // No space between sections
                                centerSpaceRadius: 0, // No gap in the middle
                              ),
                            ),
                          ),
                        ),
                        // Legend
                        Expanded(
                          flex: 1,
                          child: Container(
                            height: 200, // Match the height of the PieChart
                            padding: EdgeInsets.only(left: 16),
                            child: _buildLegend(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Color _getColorForCrowdedness(int value) {
    if (value == 0) {
      return Colors.green;
    } else if (value <= 5) {
      return Color.lerp(Colors.green, Colors.yellow, value / 5)!;
    } else if (value <= 10) {
      return Color.lerp(Colors.yellow, Colors.orange, (value - 5) / 5)!;
    } else if (value <= 20) {
      return Color.lerp(Colors.orange, Colors.red, (value - 10) / 10)!;
    } else {
      return Colors.red[900]!;
    }
  }
}

class MusclesPage extends StatefulWidget {
  final DateTime selectedDate;
  final TimeOfDay selectedTime;
  final String workoutType;

  MusclesPage({
    required this.selectedDate,
    required this.selectedTime,
    required this.workoutType,
  });

  @override
  _MusclesPageState createState() => _MusclesPageState();
}

class _MusclesPageState extends State<MusclesPage> {
  List<String> selectedMuscles = [];

  final muscleImages = {
    'Chest': 'assets/chest.png',
    'Biceps': 'assets/biceps.png',
    'Core': 'assets/core.png',
    'Calves': 'assets/calves.png',
    'Front Arm': 'assets/front_arm.png',
    'Glutes': 'assets/glutes.png',
    'Lats': 'assets/lats.png',
    'Legs': 'assets/legs.png',
    'Low Back': 'assets/low_back.png',
    'Shoulders': 'assets/shoulder.png',
    'Traps': 'assets/traps.png',
    'Triceps': 'assets/triceps.png',
  };

  final musclePositions = {
    'Chest': MusclePosition(0.67, 0.122, 0.12, 0.06),
    'Core': MusclePosition(0.643, 0.182, 0.175, 0.1),
    'Biceps Left': MusclePosition(0.58, 0.16, 0.07, 0.055),
    'Biceps Right': MusclePosition(0.81, 0.16, 0.07, 0.055),
    'Legs Left': MusclePosition(0.63, 0.31, 0.08, 0.11),
    'Legs Right': MusclePosition(0.74, 0.31, 0.08, 0.11),
    'Legs Front Left': MusclePosition(0.15, 0.31, 0.08, 0.13),
    'Calves Front Left': MusclePosition(0.135, 0.45, 0.08, 0.13),
    'Legs Front Right': MusclePosition(0.27, 0.31, 0.08, 0.13),
    'Calves Front Right': MusclePosition(0.28, 0.45, 0.08, 0.13),
    'Glutes': MusclePosition(0.17, 0.255, 0.16, 0.06),
    'Low Back': MusclePosition(0.213, 0.2, 0.07, 0.06),
    'Lats Left': MusclePosition(0.18, 0.146, 0.04, 0.08),
    'Lats Right': MusclePosition(0.28, 0.146, 0.04, 0.08),
    'Traps Center': MusclePosition(0.22, 0.15, 0.05, 0.05),
    'Traps Top': MusclePosition(0.19, 0.10, 0.11, 0.05),
    'Shoulder Left': MusclePosition(0.13, 0.10, 0.06, 0.06),
    'Shoulder Right': MusclePosition(0.305, 0.10, 0.06, 0.06),
    'Triceps Left': MusclePosition(0.31, 0.16, 0.08, 0.06),
    'Triceps Right': MusclePosition(0.1, 0.16, 0.08, 0.06),
    'Shoulder Angle Left': MusclePosition(0.79, 0.10, 0.06, 0.06, -45),
    'Shoulder Angle Right': MusclePosition(0.60, 0.10, 0.06, 0.06, 45),
    'Front Arm Left': MusclePosition(0.55, 0.22, 0.06, 0.06, 35),
    'Front Arm Right': MusclePosition(0.85, 0.22, 0.06, 0.06, -35),
  };

  final muscleGroups = {
    'Biceps Left': 'Biceps',
    'Biceps Right': 'Biceps',
    'Shoulder Left': 'Shoulders',
    'Shoulder Right': 'Shoulders',
    'Shoulder Angle Left': 'Shoulders',
    'Shoulder Angle Right': 'Shoulders',
    'Front Arm Left': 'Front Arm',
    'Front Arm Right': 'Front Arm',
    'Legs Left': 'Legs',
    'Legs Right': 'Legs',
    'Legs Front Left': 'Legs',
    'Legs Front Right': 'Legs',
    'Calves Front Left': 'Calves',
    'Calves Front Right': 'Calves',
    'Lats Left': 'Lats',
    'Lats Right': 'Lats',
    'Traps Center': 'Traps',
    'Traps Top': 'Traps',
    'Triceps Left': "Triceps",
    'Triceps Right': "Triceps",
    // Add other mappings as needed
  };

  void toggleMuscleSelection(String muscle) {
    String muscleGroup = muscleGroups[muscle] ?? muscle;

    setState(() {
      if (selectedMuscles.contains(muscleGroup)) {
        selectedMuscles.remove(muscleGroup);
      } else {
        selectedMuscles.add(muscleGroup);
      }
    });
  }

  void _navigateToSummaryPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AppointmentSummaryPage(
          selectedDate: widget.selectedDate,
          selectedTime: widget.selectedTime,
          workoutType: widget.workoutType,
          selectedMuscles: selectedMuscles,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.deepOrange),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: Text('Make Appointment',
                style: TextStyle(color: Colors.deepOrange)),
            actions: [
              TextButton(
                onPressed: _navigateToSummaryPage,
                child: Text('Next', style: TextStyle(color: Colors.deepOrange)),
              ),
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('💪 Muscles Targeted',
                    style: TextStyle(color: Colors.deepOrange, fontSize: 18)),
                SizedBox(height: 10),
                LayoutBuilder(
                  builder: (context, constraints) {
                    double containerWidth = constraints.maxWidth;
                    double containerHeight = containerWidth *
                        1.5; // Assuming a 2:3 aspect ratio for the image

                    return Container(
                      width: containerWidth,
                      child: Stack(
                        children: [
                          Image.asset(
                            'assets/body.png',
                            fit: BoxFit.contain,
                            width: containerWidth,
                          ),
                          for (var muscle in selectedMuscles)
                            if (muscleImages.containsKey(muscle))
                              Image.asset(
                                muscleImages[muscle]!,
                                fit: BoxFit.contain,
                                width: containerWidth,
                              ),
                          // Bounding boxes for muscle selection
                          for (var muscle in musclePositions.keys)
                            Positioned(
                              left: musclePositions[muscle]!.left *
                                  containerWidth,
                              top: musclePositions[muscle]!.top *
                                  containerHeight,
                              child: Transform.rotate(
                                angle:
                                    (musclePositions[muscle]!.rotation ?? 0) *
                                        3.14 /
                                        180,
                                child: GestureDetector(
                                  onTap: () => toggleMuscleSelection(muscle),
                                  child: Container(
                                    width: musclePositions[muscle]!.width *
                                        containerWidth,
                                    height: musclePositions[muscle]!.height *
                                        containerHeight,
                                    decoration: BoxDecoration(
                                      color: Colors.transparent,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ToggleButton(
                      muscle: 'Full Body',
                      isSelected: selectedMuscles.contains('Full Body'),
                      onPressed: () => toggleMuscleSelection('Full Body'),
                      isDarkMode: settingsController.isDarkMode,
                    ),
                    ToggleButton(
                      muscle: 'Cardio',
                      isSelected: selectedMuscles.contains('Cardio'),
                      onPressed: () => toggleMuscleSelection('Cardio'),
                      isDarkMode: settingsController.isDarkMode,
                    ),
                    ToggleButton(
                      muscle: 'Stretch',
                      isSelected: selectedMuscles.contains('Stretch'),
                      onPressed: () => toggleMuscleSelection('Stretch'),
                      isDarkMode: settingsController.isDarkMode,
                    ),
                  ],
                ),
                Center(
                  child: TextButton(
                    onPressed: () {
                      setState(() {
                        selectedMuscles
                            .clear(); // Clear the list to deselect all
                      });
                    },
                    child: Text('Deselect All',
                        style: TextStyle(color: Colors.deepOrange)),
                  ),
                ),
                SizedBox(height: 10),
                Text('Selected Muscles',
                    style: TextStyle(color: Colors.deepOrange, fontSize: 18)),
                SizedBox(height: 10),
                Expanded(
                  child: Scrollbar(
                    child: ListView.builder(
                      padding: EdgeInsets.zero,
                      itemCount: selectedMuscles.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: EdgeInsets.zero,
                          child: ListTile(
                            dense: true,
                            title: Text(
                              '• ${selectedMuscles[index]}', // Add a dot at the beginning
                              style: TextStyle(
                                  color: Colors.deepOrange, fontSize: 16),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class MusclePosition {
  final double left;
  final double top;
  final double width;
  final double height;
  final double? rotation;

  MusclePosition(this.left, this.top, this.width, this.height, [this.rotation]);
}

class ToggleButton extends StatelessWidget {
  final String muscle;
  final bool isSelected;
  final VoidCallback onPressed;
  final bool isDarkMode;

  const ToggleButton({
    required this.muscle,
    required this.isSelected,
    required this.onPressed,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected
            ? (isDarkMode ? Colors.deepOrange : Colors.deepOrange)
            : (isDarkMode ? Colors.black : Colors.white),
        foregroundColor: isSelected
            ? (isDarkMode ? Colors.black : Colors.deepOrange)
            : (isDarkMode ? Colors.deepOrange : Colors.deepOrange),
        side: BorderSide(color: Colors.deepOrange, width: 1),
      ),
      child: Text(
        muscle,
        style: TextStyle(
          color: isSelected
              ? (isDarkMode ? Colors.black : Colors.white)
              : Colors.deepOrange,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class AppointmentSummaryPage extends StatelessWidget {
  final DateTime selectedDate;
  final TimeOfDay selectedTime;
  final String workoutType;
  final List<String> selectedMuscles;

  const AppointmentSummaryPage({
    super.key,
    required this.selectedDate,
    required this.selectedTime,
    required this.workoutType,
    required this.selectedMuscles,
  });

  @override
  Widget build(BuildContext context) {
    String formattedDate =
        "${selectedDate.day}/${selectedDate.month}/${selectedDate.year}";
    String weekDay = [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
    ][selectedDate.weekday - 1];

    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.deepOrange),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: Text('Make Appointment',
                style: TextStyle(color: Colors.deepOrange)),
            actions: [
              TextButton(
                onPressed: () async {
                  bool isAvailable = await _checkAvailability();
                  if (isAvailable) {
                    await _saveReservation(context);
                    await _updateCrowdednessAndSessionInfo(
                        selectedDate, selectedTime, 1, selectedMuscles);
                    _showApprovalDialog(context, formattedDate, weekDay,
                        selectedTime.format(context));
                  } else {
                    _showErrorDialog(context);
                  }
                },
                child: Text('Save', style: TextStyle(color: Colors.deepOrange)),
              ),
            ],
          ),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    formattedDate,
                    style: TextStyle(color: Colors.deepOrange, fontSize: 32),
                  ),
                  Text(
                    weekDay,
                    style: TextStyle(color: Colors.deepOrange, fontSize: 32),
                  ),
                  Text(
                    selectedTime.format(context),
                    style: TextStyle(color: Colors.deepOrange, fontSize: 32),
                  ),
                  SizedBox(height: 20),
                  Text('Selected Muscles',
                      style: TextStyle(color: Colors.deepOrange, fontSize: 24)),
                  SizedBox(height: 10),
                  ...selectedMuscles.map((muscle) => Text('• $muscle',
                      style:
                          TextStyle(color: Colors.deepOrange, fontSize: 20))),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<bool> _checkAvailability() async {
    final user = FirebaseAuth.instance.currentUser;
    final snapshot = await FirebaseFirestore.instance
        .collection('reservations')
        .where('userId', isEqualTo: user?.uid)
        .where('date', isEqualTo: Timestamp.fromDate(selectedDate))
        .get();

    return snapshot.docs.isEmpty;
  }

  Future<void> _saveReservation(BuildContext context) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await FirebaseFirestore.instance.collection('reservations').add({
        'userId': user.uid,
        'date': selectedDate,
        'time': selectedTime.format(context),
        'workoutType': workoutType,
        'muscles': selectedMuscles,
      });
      // Update crowdedness data
    }
  }

  Future<void> _updateCrowdednessAndSessionInfo(DateTime selectedDate,
      TimeOfDay selectedTime, int increment, List<String> muscles) async {
    String formattedDate = DateFormat('yyyy-MM-dd').format(selectedDate);
    DateTime startTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      selectedTime.hour,
      (selectedTime.minute ~/ 10) * 10,
    );
    DateTime endTime = startTime.add(Duration(hours: 2));

    for (DateTime time = startTime;
        time.isBefore(endTime);
        time = time.add(Duration(minutes: 10))) {
      String timeKey = DateFormat.Hm().format(time);
      DocumentReference docRef = FirebaseFirestore.instance
          .collection('crowdedness')
          .doc(formattedDate)
          .collection('time_slices')
          .doc(timeKey);

      await docRef.get().then((doc) {
        if (doc.exists) {
          // Update count and muscles
          docRef.update({'count': FieldValue.increment(increment)});
          muscles.forEach((muscle) {
            docRef.update({muscle: FieldValue.increment(increment)});
          });
        } else if (increment > 0) {
          // Initialize count and muscles
          Map<String, int> initialData = {'count': increment};
          muscles.forEach((muscle) {
            initialData[muscle] = increment;
          });
          docRef.set(initialData);
        }
      });
    }
  }

  void _showApprovalDialog(BuildContext context, String formattedDate,
      String weekDay, String formattedTime) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
          child: AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            backgroundColor: Colors.greenAccent,
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    icon: Icon(Icons.close, color: Colors.black),
                    onPressed: () {
                      Navigator.of(context).pop();
                      Navigator.pushReplacementNamed(context, '/home');
                    },
                  ),
                ),
                Icon(Icons.check_circle, size: 100, color: Colors.green),
                SizedBox(height: 20),
                Text('Approved!',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black)),
                SizedBox(height: 20),
                Text('Appointment:',
                    style: TextStyle(fontSize: 18, color: Colors.black)),
                SizedBox(height: 10),
                Text(
                  '$formattedDate\n$weekDay\n$formattedTime',
                  style: TextStyle(fontSize: 18, color: Colors.black),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showErrorDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          backgroundColor: Colors.redAccent,
          title: Text('Error', style: TextStyle(color: Colors.white)),
          content: Text(
              'You already have an appointment on this date. Please choose another date.',
              style: TextStyle(color: Colors.white)),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }
}

class ContactUsPage extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  ContactUsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsController>(
      builder: (context, settingsController, child) {
        return Scaffold(
          backgroundColor:
              settingsController.isDarkMode ? Colors.black : Colors.white,
          appBar: AppBar(
            backgroundColor:
                settingsController.isDarkMode ? Colors.black : Colors.white,
            elevation: 0,
            leading: Builder(
              builder: (BuildContext context) {
                return IconButton(
                  icon: Icon(Icons.menu),
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                  color: Colors.deepOrange,
                );
              },
            ),
            title:
                Text('Contact Us', style: TextStyle(color: Colors.deepOrange)),
            centerTitle: true,
          ),
          drawer: buildDrawer(context),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Name',
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.deepOrange,
                        fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Enter your name',
                    hintStyle: TextStyle(color: Colors.deepOrange),
                    filled: true,
                    fillColor: settingsController.isDarkMode
                        ? Colors.black54
                        : Colors.white,
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                    ),
                  ),
                  style: TextStyle(color: Colors.deepOrange),
                ),
                SizedBox(height: 16),
                Text('Email',
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.deepOrange,
                        fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Enter your email',
                    hintStyle: TextStyle(color: Colors.deepOrange),
                    filled: true,
                    fillColor: settingsController.isDarkMode
                        ? Colors.black54
                        : Colors.white,
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                    ),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  style: TextStyle(color: Colors.deepOrange),
                ),
                SizedBox(height: 16),
                Text('Message',
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.deepOrange,
                        fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                TextField(
                  controller: messageController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Enter your message',
                    hintStyle: TextStyle(color: Colors.deepOrange),
                    filled: true,
                    fillColor: settingsController.isDarkMode
                        ? Colors.black54
                        : Colors.white,
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                    ),
                  ),
                  maxLines: 5,
                  style: TextStyle(color: Colors.deepOrange),
                ),
                SizedBox(height: 16),
                Center(
                  child: ElevatedButton(
                    onPressed: () {
                      String name = nameController.text;
                      String email = emailController.text;
                      String message = messageController.text;
                      print('Name: $name, Email: $email, Message: $message');
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return Consumer<SettingsController>(
                            builder: (context, settingsController, child) {
                              return AlertDialog(
                                backgroundColor: settingsController.isDarkMode
                                    ? Colors.black
                                    : Colors.white,
                                title: Text('Thank You!',
                                    style: TextStyle(color: Colors.deepOrange)),
                                content: Text('Your message has been sent.',
                                    style: TextStyle(color: Colors.deepOrange)),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text('OK',
                                        style: TextStyle(
                                            color: Colors.deepOrange)),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: settingsController.isDarkMode
                          ? Colors.black54
                          : Colors.white,
                      foregroundColor: Colors.deepOrange,
                      side: BorderSide(color: Colors.deepOrange),
                    ),
                    child: Text('Send Message',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Drawer buildDrawer(BuildContext context) {
    return Drawer(
      child: Consumer<SettingsController>(
        builder: (context, settingsController, child) {
          return Container(
            color: Colors.deepOrange,
            child: Column(
              children: <Widget>[
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: settingsController.isDarkMode
                        ? Colors.black
                        : Colors.white,
                  ),
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          icon: Icon(Icons.close, color: Colors.deepOrange),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '💪',
                          style: TextStyle(fontSize: 50),
                        ),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  title: Text('Home',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
                ListTile(
                  title: Text('Notifications',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/notifications');
                  },
                ),
                ListTile(
                  title: Text('FAQ\'s',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/faq');
                  },
                ),
                ListTile(
                  title: Text('App Settings',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                Divider(color: Colors.white),
                ListTile(
                  title: Text('Contact Us',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    Navigator.pushNamed(context, '/contactUs');
                  },
                ),
                ListTile(
                  title: Text('Log out',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                  onTap: () {
                    _showLogoutDialog(context);
                  },
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Text('buildYourself®',
                      style: TextStyle(
                        fontSize: 18,
                        color: settingsController.isDarkMode
                            ? Colors.black
                            : Colors.white,
                      )),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Consumer<SettingsController>(
          builder: (context, settingsController, child) {
            return AlertDialog(
              backgroundColor:
                  settingsController.isDarkMode ? Colors.black : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                'Are you sure you want to log out?',
                style: TextStyle(color: Colors.deepOrange),
                textAlign: TextAlign.center,
              ),
              actions: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: Icon(Icons.check, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pushReplacementNamed(context, '/login');
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      color: Color(0xFFD3D3D3),
                    ),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }
}
