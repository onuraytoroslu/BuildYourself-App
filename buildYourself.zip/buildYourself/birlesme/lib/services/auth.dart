import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:testapp/models/user.dart';

class AuthService {

  final FirebaseAuth _auth = FirebaseAuth.instance;

  CustomUser _customUser(User user) {
    return CustomUser(uid: user.uid);
  }

  Stream<User> get user {
    return _auth.authStateChanges() as Stream<User>;
  }

  // sign in anon
  Future signInAnon() async{
    try{
      UserCredential credential = await _auth.signInAnonymously();
      User user = credential.user as User;
      return _customUser(user);
    }catch(e){
      print(e.toString());
      return null;
    }
  }

  // sign in with email and password

  // register with email and password

  //sign out
}